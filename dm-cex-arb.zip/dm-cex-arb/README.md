# Dennis Mutinda Arbitrage Test Scanner

Full **web app** (PWA UI + Node backend + **WebSocket** live updates) for **CEX arbitrage**.

## Features
- Spot→Spot, Spot↔Futures, Futures→Futures
- Backend scans 19 exchanges (no browser CORS)
- **Real-time WebSocket** pushes (`/ws`) every ~10s
- Manual refresh + strategy filters

## Local run

```bash
npm install
npm start
```

Open **http://localhost:8787**

- REST: `GET /api/scan`, `GET /api/health`
- WebSocket: `ws://localhost:8787/ws`

Env: `PORT` (default 8787), `WS_SCAN_MS` (default 10000).

## Deploy to Railway

### Option A — Railway dashboard
1. Push this folder to a **GitHub** repo (or use Railway CLI).
2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub**.
3. Select the repo. Railway detects Node and runs `npm start`.
4. Open the generated public URL (HTTPS + WSS work automatically).

### Option B — Railway CLI
```bash
npm i -g @railway/cli
railway login
railway init
railway up
railway domain
```

### Notes
- Railway sets `PORT` automatically — the server binds `0.0.0.0:$PORT`.
- Health check: `/api/health`
- After deploy, the header should show **Live WS · connected**.

## Message format (WebSocket)
```json
{ "type": "scan", "ts": 123, "status": {}, "books": {}, "exchanges": [] }
{ "type": "hello", "intervalMs": 10000 }
{ "type": "error", "error": "..." }
```

Client may send: `{ "type": "refresh" }` or `{ "type": "ping" }`.

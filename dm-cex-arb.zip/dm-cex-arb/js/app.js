
// Promise.any polyfill (older Android WebViews)
if (typeof Promise.any !== 'function') {
  Promise.any = function (promises) {
    return new Promise((resolve, reject) => {
      const errors = [];
      let rejected = 0;
      const list = Array.from(promises);
      if (!list.length) return reject(new AggregateError([], 'All promises were rejected'));
      list.forEach((p, i) => {
        Promise.resolve(p).then(resolve, (err) => {
          errors[i] = err;
          rejected++;
          if (rejected === list.length) reject(new AggregateError(errors, 'All promises were rejected'));
        });
      });
    });
  };
}
/**
 * Dennis Mutinda Arbitrage Test Scanner — CEX only
 * Strategies: Spot→Spot | Spot↔Futures | Futures→Futures
 * Shows live order-book spreads even when fees > gross profit.
 */

/** Track all USDT (and USDC) pairs found on connected exchanges */
const QUOTE_SUFFIXES = ['USDT', 'USDC'];
const MAX_OPPS_SHOWN = 150;
const MIN_SPREAD_BPS = 0.5;
const MAX_SPREAD_BPS = 300; // >3% almost always bad data / symbol mismatch
const MIN_LIQ_USDT = 50;
const MIN_EXCHANGES_FOR_PAIR = 2; // need the pair on ≥2 venues to arb

/** Display names — full list. Backend /api/scan fetches all (no CORS). Browser mode uses subset with public CORS. */
const EXCHANGES = {
  binance: { name: 'Binance', spot: 'https://data-api.binance.vision/api/v3/ticker/bookTicker', fut: 'https://fapi.binance.com/fapi/v1/ticker/bookTicker' },
  bybit: { name: 'Bybit', spot: 'https://api.bybit.com/v5/market/tickers?category=spot', fut: 'https://api.bybit.com/v5/market/tickers?category=linear' },
  bitget: { name: 'Bitget', spot: 'https://api.bitget.com/api/v2/spot/market/tickers', fut: 'https://api.bitget.com/api/v2/mix/market/tickers?productType=USDT-FUTURES' },
  okx: { name: 'OKX', spot: 'https://www.okx.com/api/v5/market/tickers?instType=SPOT', fut: 'https://www.okx.com/api/v5/market/tickers?instType=SWAP' },
  bingx: { name: 'BingX', spot: 'https://open-api.bingx.com/openApi/spot/v1/ticker/24hr' },
  xt: { name: 'XT.com', spot: 'https://sapi.xt.com/v4/public/ticker/book' },
  mexc: { name: 'MEXC', spot: 'https://api.mexc.com/api/v3/ticker/bookTicker' },
  gate: { name: 'Gate.io', spot: 'https://api.gateio.ws/api/v4/spot/tickers', fut: 'https://api.gateio.ws/api/v4/futures/usdt/tickers' },
  htmt: { name: 'HTX', spot: 'https://api.huobi.pro/market/tickers' },
  weex: { name: 'WEEX', spot: 'https://api-spot.weex.com/api/v2/market/tickers' },
  bitrue: { name: 'Bitrue', spot: 'https://openapi.bitrue.com/api/v1/ticker/bookTicker' },
  coinex: { name: 'CoinEx', spot: 'https://api.coinex.com/v1/market/ticker/all' },
  kraken: { name: 'Kraken', spot: 'https://api.kraken.com/0/public/Ticker?pair=XBTUSDT,ETHUSDT,SOLUSDT,XRPUSDT,ADAUSDT,DOTUSDT,LINKUSDT,LTCUSDT,AVAXUSDT,ATOMUSDT' },
  lbank: { name: 'LBank', spot: 'https://api.lbkex.com/v2/supplement/ticker/price.do' },
  kucoin: { name: 'KuCoin', spot: 'https://api.kucoin.com/api/v1/market/allTickers', fut: 'https://api-futures.kucoin.com/api/v1/allTickers' },
  cryptocom: { name: 'Crypto.com', spot: 'https://api.crypto.com/exchange/v1/public/get-tickers' },
  bitfinex: { name: 'Bitfinex', spot: 'https://api-pub.bitfinex.com/v2/tickers?symbols=ALL' },
  blofin: { name: 'Blofin', spot: 'https://openapi.blofin.com/api/v1/market/tickers' },
  levex: { name: 'Levex', spot: 'https://api.levex.com/api/v1/ticker/24hr' },
};

/** Prefer same-origin backend (Node server). Set false to force browser-only. */
const USE_BACKEND = true;
const BACKEND_SCAN = '/api/scan';


const TAKER = {
  binance: 0.001, bybit: 0.001, okx: 0.001, bitget: 0.001,
  gate: 0.002, kucoin: 0.001, mexc: 0.001, htmt: 0.002, default: 0.0015,
};
const WD_FEE = { BTC: 15, ETH: 3, SOL: 1, XRP: 0.25, default: 2 };

const PROXIES = [
  (u) => 'https://corsproxy.io/?' + encodeURIComponent(u),
  (u) => 'https://api.allorigins.win/raw?url=' + encodeURIComponent(u),
];

const STRATEGY_LABEL = {
  'spot-spot': 'Spot → Spot',
  'spot-futures': 'Spot → Futures',
  'futures-spot': 'Futures → Spot',
  'futures-futures': 'Futures → Futures',
};
const STRATEGY_HELP = {
  'spot-spot': 'Buy spot on exchange A, withdraw/transfer, sell spot on exchange B.',
  'spot-futures': 'Buy spot on A, sell perpetual/futures on B.',
  'futures-spot': 'Buy perpetual/futures on A, sell spot on B.',
  'futures-futures': 'Buy perp on A, sell perp on B (account hedge; no coin transfer).',
};

let state = {
  books: {},
  status: {},
  opps: [],
  trackedPairs: [],   // all symbols seen on ≥1 exchange
  multiVenuePairs: [], // symbols on ≥2 exchanges
  pairExchangeMap: {}, // symbol -> [exchange ids]
  filter: 'all',
  profitableOnly: false,
  selected: null,
  scanning: false,
  autoTimer: null,
  trackTimer: null,
  backendMode: null,
  ws: null,
  wsConnected: false,
  liveMode: true,
  wsReconnectAttempt: 0,
  wsPingTimer: null,
  wsReconnectTimer: null,
  wsEverConnected: false,
};

function $(id) { return document.getElementById(id); }
function toast(msg, type) {
  const el = $('toast');
  if (!el) return;
  el.textContent = msg;
  el.className = 'toast ' + (type || '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add('hidden'), 4000);
}
function money(n) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(n || 0);
}
function fmtPx(p) {
  if (!(p > 0)) return '—';
  if (p >= 1000) return Number(p).toFixed(2);
  if (p >= 1) return Number(p).toFixed(4);
  return Number(p).toPrecision(4);
}
function fmtVol(v) {
  if (!(v > 0)) return '—';
  if (v >= 1e9) return (v / 1e9).toFixed(2) + 'B';
  if (v >= 1e6) return (v / 1e6).toFixed(2) + 'M';
  if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
  return Number(v).toFixed(0);
}
function normSym(s) {
  s = String(s || '').toUpperCase().replace(/[-_/]/g, '');
  if (s.endsWith('USD') && !s.endsWith('USDT')) s += 'T';
  return s;
}
function baseOf(sym) {
  const s = normSym(sym);
  return s.endsWith('USDT') ? s.slice(0, -4) : s;
}
function fee(ex) { return TAKER[ex] != null ? TAKER[ex] : TAKER.default; }
function exName(id) { return (EXCHANGES[id] && EXCHANGES[id].name) || id; }

async function fetchDirect(url, ms) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms || 5000);
  try {
    const res = await fetch(url, { signal: ctrl.signal, mode: 'cors', headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

/** Direct first (5s). If fail, race proxies in parallel (6s) instead of sequential. */
async function fetchJson(url) {
  try {
    return { data: await fetchDirect(url, 5000), proxy: false };
  } catch (e1) {
    const jobs = PROXIES.map((p) => fetchDirect(p(url), 6000).then((data) => ({ data: data, proxy: true })));
    try {
      return await Promise.any(jobs);
    } catch (_) {
      throw e1;
    }
  }
}

function parseBooks(exchangeId, data, market) {
  const out = {};
  const put = (sym, bid, ask, bidQty, askQty, vol) => {
    const s = normSym(sym);
    // Accept any pair quoted in USDT or USDC
    if (!QUOTE_SUFFIXES.some((q) => s.endsWith(q))) return;
    // Skip leveraged tokens / weird suffixes when possible
    if (/UPUSDT$|DOWNUSDT$|BULLUSDT$|BEARUSDT$|3L|3S|5L|5S/.test(s)) return;
    const b = parseFloat(bid);
    const a = parseFloat(ask);
    if (!(b > 0) || !(a > 0) || a < b) return;
    const bq = parseFloat(bidQty) || 0;
    const aq = parseFloat(askQty) || 0;
    let liq = Math.min(b * bq, a * aq);
    const volume = parseFloat(vol) || 0;
    if (!(liq > 0)) liq = volume > 0 ? Math.min(volume, 100000) : 5000;
    out[s] = {
      exchange: exchangeId, market: market, symbol: s,
      bid: b, ask: a, bidQty: bq, askQty: aq,
      liquidityUsdt: liq, volume24hUsdt: volume,
    };
  };

  try {
    if (exchangeId === 'binance' || exchangeId === 'mexc') {
      (Array.isArray(data) ? data : [data]).forEach((t) => put(t.symbol, t.bidPrice, t.askPrice, t.bidQty, t.askQty));
    } else if (exchangeId === 'bybit') {
      ((data.result && data.result.list) || []).forEach((t) =>
        put(t.symbol, t.bid1Price, t.ask1Price, t.bid1Size, t.ask1Size, t.turnover24h)
      );
    } else if (exchangeId === 'okx') {
      (data.data || []).forEach((t) =>
        put(String(t.instId).replace(/-/g, ''), t.bidPx, t.askPx, t.bidSz, t.askSz, t.volCcy24h)
      );
    } else if (exchangeId === 'bitget') {
      const arr = data.data || data;
      (Array.isArray(arr) ? arr : []).forEach((t) => {
        const sym = String(t.symbol || '').replace(/_/g, '');
        put(sym, t.bidPr || t.bestBid || t.bidPrice, t.askPr || t.bestAsk || t.askPrice, t.bidSz, t.askSz, t.usdtVolume || t.quoteVolume);
      });
    } else if (exchangeId === 'gate') {
      (Array.isArray(data) ? data : []).forEach((t) => {
        const sym = String(t.currency_pair || t.contract || '').replace(/_/g, '');
        put(sym, t.highest_bid, t.lowest_ask, t.highest_size, t.lowest_size, t.quote_volume);
      });
    } else if (exchangeId === 'kucoin') {
      const list = (data.data && data.data.ticker) || [];
      list.forEach((t) => put(String(t.symbol || '').replace(/-/g, ''), t.buy, t.sell, 0, 0, t.volValue));
    } else if (exchangeId === 'htmt') {
      (data.data || []).forEach((t) => put(t.symbol, t.bid, t.ask, t.bidSize, t.askSize));
    }
  } catch (err) {
    console.warn('parse', exchangeId, err);
  }
  return out;
}

async function loadExchange(id, cfg, opts) {
  opts = opts || {};
  const includeFutures = opts.includeFutures !== false;
  const books = {};
  let status = 'ok';
  let usedProxy = false;

  async function load(url, market) {
    const res = await fetchJson(url);
    usedProxy = usedProxy || res.proxy;
    const parsed = parseBooks(id, res.data, market);
    const keys = Object.keys(parsed);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      books[market === 'futures' ? k + '__FUT' : k] = parsed[k];
    }
  }

  // Run spot + futures in parallel (skip slow 24h volume endpoint on scan)
  const jobs = [];
  if (cfg.spot) jobs.push(load(cfg.spot, 'spot').catch((e) => { status = 'cors'; }));
  if (includeFutures && cfg.fut) jobs.push(load(cfg.fut, 'futures').catch(() => {}));
  await Promise.all(jobs);

  if (!Object.keys(books).length) status = status === 'ok' ? 'empty' : status;
  else if (usedProxy) status = 'ok-proxy';
  return { books: books, status: status };
}

/**
 * Build opportunities from positive gross spreads.
 * Keep rows even if net after fees is negative — mark profitable flag.
 */
function buildOpps(allBooks) {
  const now = Date.now();
  const buckets = {};

  Object.keys(allBooks).forEach((ex) => {
    const books = allBooks[ex] || {};
    Object.keys(books).forEach((key) => {
      const row = books[key];
      const isFut = key.indexOf('__FUT') >= 0;
      const sym = key.replace('__FUT', '');
      const bkey = sym + '|' + (isFut ? 'fut' : 'spot');
      if (!buckets[bkey]) buckets[bkey] = [];
      buckets[bkey].push(Object.assign({ exchange: ex, symbol: sym }, row));
    });
  });

  const opps = [];

  function consider(buy, sell, strategy) {
    if (!buy || !sell || buy.exchange === sell.exchange) return;
    if (!(sell.bid > buy.ask)) return;
    // Same symbol must have comparable prices — reject wild mismatches (wrong asset / bad tickers)
    const ratio = sell.bid / buy.ask;
    if (!(ratio > 1) || ratio > 1 + MAX_SPREAD_BPS / 10000) return;
    if (buy.ask <= 0 || sell.bid <= 0) return;
    // Prices on both sides should be same order of magnitude
    const mag = Math.log10(sell.bid) - Math.log10(buy.ask);
    if (Math.abs(mag) > 0.05) return; // > ~12% price scale difference → discard

    const size = Math.min(
      2000,
      buy.liquidityUsdt > 0 ? buy.liquidityUsdt : 0,
      sell.liquidityUsdt > 0 ? sell.liquidityUsdt : 0
    );
    if (!(size >= MIN_LIQ_USDT)) return;

    const spread = (sell.bid - buy.ask) / buy.ask;
    const spreadBps = spread * 10000;
    if (spreadBps < MIN_SPREAD_BPS || spreadBps > MAX_SPREAD_BPS) return;

    const tradeFeeRate = fee(buy.exchange) + fee(sell.exchange);
    const tradeFee = size * tradeFeeRate;
    const needsTransfer = strategy === 'spot-spot';
    const transferFee = needsTransfer
      ? (WD_FEE[baseOf(buy.symbol)] || WD_FEE.default)
      : (strategy.indexOf('futures') >= 0 ? 0.5 : WD_FEE.default);
    const gross = size * spread;
    const net = gross - tradeFee - transferFee;
    const feeBps = tradeFeeRate * 10000;

    opps.push({
      id: strategy + '-' + buy.exchange + '-' + sell.exchange + '-' + buy.symbol + '-' + now,
      strategy: strategy,
      strategyLabel: STRATEGY_LABEL[strategy] || strategy,
      strategyHelp: STRATEGY_HELP[strategy] || '',
      symbol: buy.symbol,
      buyExchange: buy.exchange,
      sellExchange: sell.exchange,
      buyBid: buy.bid,
      buyAsk: buy.ask,
      buyVol: buy.volume24hUsdt || 0,
      sellBid: sell.bid,
      sellAsk: sell.ask,
      sellVol: sell.volume24hUsdt || 0,
      buyPrice: buy.ask,
      sellPrice: sell.bid,
      spreadBps: Number(spreadBps.toFixed(2)),
      feeBps: Number(feeBps.toFixed(2)),
      sizeUsdt: Number(size.toFixed(2)),
      grossProfit: gross,
      tradingFees: tradeFee,
      transferFee: transferFee,
      totalFees: tradeFee + transferFee,
      netProfit: net,
      profitable: net > 0,
      liquidityUsdt: size,
      detectedAt: now,
      trackStatus: 'unknown',
    });
  }

  Object.keys(buckets).forEach((bkey) => {
    const rows = buckets[bkey];
    if (rows.length < 2) return;
    const market = bkey.endsWith('|fut') ? 'futures' : 'spot';
    let bestBid = null, bestAsk = null;
    rows.forEach((r) => {
      if (!bestBid || r.bid > bestBid.bid) bestBid = r;
      if (!bestAsk || r.ask < bestAsk.ask) bestAsk = r;
    });
    consider(bestAsk, bestBid, market === 'spot' ? 'spot-spot' : 'futures-futures');
  });

  // Spot ↔ futures for every symbol that has both markets
  const allSyms = {};
  Object.keys(buckets).forEach((bk) => {
    allSyms[bk.split('|')[0]] = true;
  });
  Object.keys(allSyms).forEach((sym) => {
    const spots = buckets[sym + '|spot'] || [];
    const futs = buckets[sym + '|fut'] || [];
    if (!spots.length || !futs.length) return;
    let spotAsk = null, spotBid = null, futAsk = null, futBid = null;
    spots.forEach((r) => {
      if (!spotAsk || r.ask < spotAsk.ask) spotAsk = r;
      if (!spotBid || r.bid > spotBid.bid) spotBid = r;
    });
    futs.forEach((r) => {
      if (!futAsk || r.ask < futAsk.ask) futAsk = r;
      if (!futBid || r.bid > futBid.bid) futBid = r;
    });
    if (spotAsk && futBid) consider(spotAsk, futBid, 'spot-futures');
    if (futAsk && spotBid) consider(futAsk, spotBid, 'futures-spot');
  });

  // Sort: profitable first, then highest spread
  opps.sort((a, b) => {
    if (a.profitable !== b.profitable) return a.profitable ? -1 : 1;
    return b.spreadBps - a.spreadBps;
  });
  return opps.slice(0, MAX_OPPS_SHOWN);
}

function catalogPairs(all) {
  const pairMap = {};
  Object.keys(all).forEach((ex) => {
    Object.keys(all[ex] || {}).forEach((key) => {
      const sym = key.replace('__FUT', '');
      if (!pairMap[sym]) pairMap[sym] = {};
      pairMap[sym][ex] = true;
    });
  });
  const tracked = Object.keys(pairMap);
  const multi = tracked.filter((s) => Object.keys(pairMap[s]).length >= MIN_EXCHANGES_FOR_PAIR);
  state.trackedPairs = tracked;
  state.multiVenuePairs = multi;
  state.pairExchangeMap = {};
  for (let i = 0; i < tracked.length; i++) {
    state.pairExchangeMap[tracked[i]] = Object.keys(pairMap[tracked[i]]);
  }
}

function rebuildFromBooks() {
  catalogPairs(state.books);
  state.opps = buildOpps(state.books);
}

async function scanViaBackend(onProgress) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 45000);
  try {
    if (onProgress) onProgress(0, Object.keys(EXCHANGES).length);
    const res = await fetch(apiBase() + BACKEND_SCAN, { signal: ctrl.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('backend HTTP ' + res.status);
    const data = await res.json();
    if (!data || !data.books) throw new Error('invalid backend response');
    state.books = data.books;
    state.status = data.status || {};
    // Ensure every known exchange has a status entry
    Object.keys(EXCHANGES).forEach((id) => {
      if (!state.status[id]) state.status[id] = 'error';
    });
    state.backendMode = true;
    rebuildFromBooks();
    if (onProgress) onProgress(Object.keys(EXCHANGES).length, Object.keys(EXCHANGES).length);
    return state.opps;
  } finally {
    clearTimeout(t);
  }
}

async function scanViaBrowser(onProgress) {
  const ids = Object.keys(EXCHANGES);
  const order = ['binance', 'gate', 'okx', 'kucoin', 'mexc', 'bitget', 'bybit', 'htmt', 'coinex', 'kraken', 'bitrue'];
  const sorted = order.filter((id) => EXCHANGES[id]).concat(ids.filter((id) => order.indexOf(id) < 0));
  let done = 0;
  let lastUi = 0;
  state.backendMode = false;

  await Promise.all(sorted.map(async (id) => {
    const cfg = EXCHANGES[id];
    if (!cfg || !cfg.spot) {
      state.status[id] = 'empty';
      state.books[id] = {};
      done++;
      return;
    }
    try {
      const res = await loadExchange(id, cfg, { includeFutures: true });
      state.books[id] = res.books;
      state.status[id] = res.status;
    } catch (e) {
      state.books[id] = state.books[id] || {};
      state.status[id] = 'error';
    }
    done++;
    const now = Date.now();
    if (onProgress && (done <= 2 || done === sorted.length || now - lastUi > 400)) {
      lastUi = now;
      rebuildFromBooks();
      try { onProgress(done, sorted.length); } catch (_) {}
    }
  }));
  rebuildFromBooks();
  return state.opps;
}

async function scanAll(onProgress) {
  if (state.scanning) return state.opps;
  state.scanning = true;
  try {
    if (USE_BACKEND) {
      try {
        await scanViaBackend(onProgress);
        return state.opps;
      } catch (e) {
        console.warn('Backend scan failed, falling back to browser:', e.message || e);
        state.backendMode = false;
      }
    }
    await scanViaBrowser(onProgress);
    return state.opps;
  } finally {
    state.scanning = false;
  }
}

function filteredOpps() {
  let list = state.opps.slice();
  if (state.filter === 'spot-futures') {
    list = list.filter((o) => o.strategy === 'spot-futures' || o.strategy === 'futures-spot');
  } else if (state.filter !== 'all') {
    list = list.filter((o) => o.strategy === state.filter);
  }
  if (state.profitableOnly) list = list.filter((o) => o.profitable);
  return list;
}

function renderPairs() {
  const pairEl = $('pairCount');
  const multiEl = $('multiPairCount');
  const summary = $('pairSummary');
  if (pairEl) pairEl.textContent = String((state.trackedPairs || []).length);
  if (multiEl) multiEl.textContent = String((state.multiVenuePairs || []).length);
  if (!summary) return;

  const multi = state.multiVenuePairs || [];
  const map = state.pairExchangeMap || {};
  if (!multi.length) {
    summary.textContent = 'No pairs loaded yet. Tap Check all exchanges.';
    return;
  }

  // Show multi-venue pairs first (arb candidates), capped for UI
  const show = multi.slice(0, 200);
  summary.innerHTML =
    '<div style="margin-bottom:6px;color:var(--text);"><b>' + multi.length + '</b> pairs listed on ≥2 exchanges · <b>' +
    (state.trackedPairs || []).length + '</b> total pairs discovered</div>' +
    show.map((sym) => {
      const exs = (map[sym] || []).map(exName).join(', ');
      return '<div><b style="color:var(--text)">' + sym + '</b> · ' + exs + '</div>';
    }).join('') +
    (multi.length > 200 ? '<div style="margin-top:6px;">…and ' + (multi.length - 200) + ' more</div>' : '');
}

function renderStatus() {
  const el = $('exchangeStatus');
  if (!el) return;
  const ids = Object.keys(state.status);
  if (!ids.length) {
    el.innerHTML = '<span class="badge">Not scanned yet</span>';
    return;
  }
  const modeBadge = state.backendMode === true
    ? '<span class="badge live">Mode: Backend (all exchanges)</span>'
    : (state.backendMode === false ? '<span class="badge warn">Mode: Browser (CORS limited)</span>' : '');
  el.innerHTML = modeBadge + ids.map((id) => {
    const st = state.status[id];
    let cls = 'badge bad', label = 'Error';
    if (st === 'ok') { cls = 'badge live'; label = 'Live'; }
    else if (st === 'ok-proxy') { cls = 'badge live'; label = 'Proxy'; }
    else if (st === 'cors') { cls = 'badge warn'; label = 'Blocked'; }
    else if (st === 'empty') { cls = 'badge warn'; label = 'Empty'; }
    return '<span class="' + cls + '">' + exName(id) + ': ' + label + '</span>';
  }).join('');
}

function renderList() {
  const list = $('oppList');
  const opps = filteredOpps();
  $('oppCount').textContent = String(opps.length);
  const best = opps.find((o) => o.profitable) || opps[0];
  $('bestProfit').textContent = best ? (best.profitable ? money(best.netProfit) : best.spreadBps + ' bps') : '$0';

  if (!opps.length) {
    const liveCount = Object.keys(state.status).filter((k) => state.status[k] === 'ok' || state.status[k] === 'ok-proxy').length;
    list.innerHTML =
      '<div class="empty">' +
        '<p><b>No spreads in this filter.</b></p>' +
        '<p style="margin-top:10px;font-size:0.85rem;line-height:1.5;">' +
          (liveCount ? liveCount + ' exchange(s) connected. Markets may be tightly aligned after fees.' : 'No exchanges connected. CORS may be blocking this host — try again or another network.') +
        '</p>' +
        '<p style="margin-top:8px;font-size:0.8rem;color:var(--muted);">Turn off “Profitable only” to see raw live spreads.</p>' +
      '</div>';
    return;
  }

  list.innerHTML = opps.map((o) => {
    const buyN = exName(o.buyExchange);
    const sellN = exName(o.sellExchange);
    const stratClass = o.strategy === 'futures-spot' ? 'spot-futures' : o.strategy;
    const profitCls = o.profitable ? 'profit' : 'profit' ;
    const profitTxt = o.profitable ? ('+' + money(o.netProfit)) : (o.spreadBps + ' bps');
    const profitColor = o.profitable ? 'var(--success)' : 'var(--warning)';
    const flag = o.profitable
      ? '<span style="color:var(--success);font-weight:700;font-size:0.75rem;">PROFITABLE after fees</span>'
      : '<span style="color:var(--warning);font-weight:700;font-size:0.75rem;">SPREAD ONLY — fees ≥ profit</span>';

    return (
      '<div class="card" data-id="' + o.id + '">' +
        '<div class="card-top">' +
          '<div>' +
            '<div class="pair">' + o.symbol + '</div>' +
            '<span class="strategy ' + stratClass + '">' + o.strategyLabel + '</span>' +
          '</div>' +
          '<div class="' + profitCls + '" style="color:' + profitColor + '">' + profitTxt + '</div>' +
        '</div>' +
        '<div style="margin-top:6px;">' + flag + '</div>' +
        '<div class="meta">' +
          '<div><b>Route:</b> Buy ' + buyN + ' @ ' + fmtPx(o.buyAsk) + ' → Sell ' + sellN + ' @ ' + fmtPx(o.sellBid) + '</div>' +
          '<div><b>Buy book:</b> bid ' + fmtPx(o.buyBid) + ' / ask ' + fmtPx(o.buyAsk) + ' · 24h vol ' + fmtVol(o.buyVol) + '</div>' +
          '<div><b>Sell book:</b> bid ' + fmtPx(o.sellBid) + ' / ask ' + fmtPx(o.sellAsk) + ' · 24h vol ' + fmtVol(o.sellVol) + '</div>' +
          '<div><b>Spread:</b> ' + o.spreadBps + ' bps · <b>Trade fee:</b> ~' + o.feeBps + ' bps · <b>Net:</b> ' + money(o.netProfit) + '</div>' +
        '</div>' +
        '<button type="button" class="track-btn" data-id="' + o.id + '">Open & track this pair</button>' +
      '</div>'
    );
  }).join('');

  list.querySelectorAll('.track-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const opp = state.opps.find((x) => x.id === btn.getAttribute('data-id'));
      if (opp) openDetail(opp);
    });
  });
  list.querySelectorAll('.card').forEach((card) => {
    card.addEventListener('click', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('track-btn')) return;
      const opp = state.opps.find((x) => x.id === card.getAttribute('data-id'));
      if (opp) openDetail(opp);
    });
  });
}

function trackLabel(st) {
  if (st === 'still_exists') return '<span style="color:var(--success)">● STILL EXISTS</span>';
  if (st === 'weakened') return '<span style="color:var(--warning)">● WEAKENED</span>';
  if (st === 'gone') return '<span style="color:var(--danger)">● GONE</span>';
  if (st === 'unprofitable') return '<span style="color:var(--warning)">● UNPROFITABLE after fees</span>';
  return '<span style="color:var(--muted)">● Not checked yet</span>';
}

function openDetail(o) {
  state.selected = o;
  $('modalTitle').textContent = o.symbol + ' · ' + o.strategyLabel;
  $('modalBody').innerHTML =
    '<div class="row"><span class="label">Strategy</span><span class="value">' + o.strategyLabel + '</span></div>' +
    '<p style="font-size:0.8rem;color:var(--muted);margin:8px 0 12px;">' + o.strategyHelp + '</p>' +
    '<div class="row"><span class="label">Status</span><span class="value" id="dStatus">' + trackLabel(o.trackStatus) + '</span></div>' +
    '<div class="row"><span class="label">Profitable after fees?</span><span class="value" style="color:' + (o.profitable ? 'var(--success)' : 'var(--warning)') + '">' + (o.profitable ? 'YES' : 'NO') + '</span></div>' +
    '<div class="row"><span class="label">Buy</span><span class="value">' + exName(o.buyExchange) + '</span></div>' +
    '<div class="row"><span class="label">Buy book</span><span class="value">bid ' + fmtPx(o.buyBid) + ' / ask ' + fmtPx(o.buyAsk) + '</span></div>' +
    '<div class="row"><span class="label">Buy 24h vol</span><span class="value">' + fmtVol(o.buyVol) + ' USDT</span></div>' +
    '<div class="row"><span class="label">Sell</span><span class="value">' + exName(o.sellExchange) + '</span></div>' +
    '<div class="row"><span class="label">Sell book</span><span class="value">bid ' + fmtPx(o.sellBid) + ' / ask ' + fmtPx(o.sellAsk) + '</span></div>' +
    '<div class="row"><span class="label">Sell 24h vol</span><span class="value">' + fmtVol(o.sellVol) + ' USDT</span></div>' +
    '<div class="row"><span class="label">Spread</span><span class="value" id="dSpread">' + o.spreadBps + ' bps</span></div>' +
    '<div class="row"><span class="label">Trading fees</span><span class="value">' + money(o.tradingFees) + ' (~' + o.feeBps + ' bps)</span></div>' +
    '<div class="row"><span class="label">Transfer / buffer</span><span class="value">' + money(o.transferFee) + '</span></div>' +
    '<div class="row"><span class="label">Gross</span><span class="value">' + money(o.grossProfit) + '</span></div>' +
    '<div class="row"><span class="label">Net after fees</span><span class="value" id="dNet" style="color:' + (o.netProfit > 0 ? 'var(--success)' : 'var(--danger)') + '">' + money(o.netProfit) + '</span></div>';
  $('modal').classList.remove('hidden');
}

async function recheckSelected() {
  const o = state.selected;
  if (!o) return o;
  const buyRes = await loadExchange(o.buyExchange, EXCHANGES[o.buyExchange]);
  const sellRes = await loadExchange(o.sellExchange, EXCHANGES[o.sellExchange]);
  state.books[o.buyExchange] = buyRes.books;
  state.books[o.sellExchange] = sellRes.books;

  let bRow, sRow;
  if (o.strategy === 'spot-spot') {
    bRow = buyRes.books[o.symbol];
    sRow = sellRes.books[o.symbol];
  } else if (o.strategy === 'futures-futures') {
    bRow = buyRes.books[o.symbol + '__FUT'];
    sRow = sellRes.books[o.symbol + '__FUT'];
  } else if (o.strategy === 'spot-futures') {
    bRow = buyRes.books[o.symbol];
    sRow = sellRes.books[o.symbol + '__FUT'] || sellRes.books[o.symbol];
  } else {
    bRow = buyRes.books[o.symbol + '__FUT'] || buyRes.books[o.symbol];
    sRow = sellRes.books[o.symbol];
  }

  if (!bRow || !sRow || !(sRow.bid > bRow.ask)) {
    o.trackStatus = 'gone';
    o.spreadBps = 0;
    o.netProfit = 0;
    o.profitable = false;
  } else {
    o.buyBid = bRow.bid; o.buyAsk = bRow.ask; o.buyVol = bRow.volume24hUsdt || o.buyVol;
    o.sellBid = sRow.bid; o.sellAsk = sRow.ask; o.sellVol = sRow.volume24hUsdt || o.sellVol;
    const spread = (sRow.bid - bRow.ask) / bRow.ask;
    const tradeFee = o.sizeUsdt * (fee(o.buyExchange) + fee(o.sellExchange));
    const gross = o.sizeUsdt * spread;
    const net = gross - tradeFee - o.transferFee;
    o.spreadBps = Number((spread * 10000).toFixed(2));
    o.tradingFees = tradeFee;
    o.totalFees = tradeFee + o.transferFee;
    o.grossProfit = gross;
    o.netProfit = net;
    o.profitable = net > 0;
    o.trackStatus = net > 0 ? 'still_exists' : (spread > 0 ? 'unprofitable' : 'gone');
  }

  const idx = state.opps.findIndex((x) => x.id === o.id);
  if (idx >= 0) state.opps[idx] = o;
  openDetail(o);
  renderList();
  return o;
}

async function runScan() {
  const btn = $('scanBtn');
  btn.disabled = true;
  const t0 = Date.now();
  btn.textContent = 'Scanning…';
  try {
    await scanAll((done, total) => {
      btn.textContent = 'Scanning ' + done + '/' + total + '…';
      $('lastScan').textContent = new Date().toLocaleTimeString();
      renderStatus();
      renderPairs();
      renderList();
    });
    const ms = Date.now() - t0;
    $('lastScan').textContent = new Date().toLocaleTimeString();
    renderStatus();
    renderPairs();
    renderList();
    const live = Object.keys(state.status).filter((k) => state.status[k] === 'ok' || state.status[k] === 'ok-proxy').length;
    const n = filteredOpps().length;
    const prof = state.opps.filter((o) => o.profitable).length;
    const pairs = (state.trackedPairs || []).length;
    const multi = (state.multiVenuePairs || []).length;
    const mode = state.backendMode ? 'backend' : 'browser';
    toast(ms + 'ms · ' + mode + ' · ' + live + ' live · ' + pairs + ' pairs · ' + multi + ' multi-venue · ' + n + ' spreads', n ? 'success' : '');
  } catch (e) {
    console.error(e);
    toast('Scan failed: ' + (e.message || 'error'), 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Check all exchanges';
  }
}



function wsUrl() {
  // Allow override for installed PWA pointing at a remote Railway backend
  try {
    const custom = localStorage.getItem('dm_ws_url') || localStorage.getItem('dm_api_base');
    if (custom) {
      const base = custom.replace(/\/$/, '');
      if (base.startsWith('wss:') || base.startsWith('ws:')) return base.endsWith('/ws') ? base : base + '/ws';
      if (base.startsWith('https:')) return base.replace(/^https/, 'wss') + '/ws';
      if (base.startsWith('http:')) return base.replace(/^http/, 'ws') + '/ws';
    }
  } catch (_) {}
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  return proto + '//' + location.host + '/ws';
}

function apiBase() {
  try {
    const custom = localStorage.getItem('dm_api_base');
    if (custom) return custom.replace(/\/$/, '');
  } catch (_) {}
  return '';
}

function setWsStatus(text, kind) {
  const el = $('backendStatus');
  if (!el) return;
  el.className = 'badge ' + (kind === 'live' ? 'live' : kind === 'bad' ? 'bad' : 'warn');
  el.textContent = text;
}

function applyScanPayload(data) {
  if (!data || !data.books) return;
  state.books = data.books;
  state.status = data.status || {};
  Object.keys(EXCHANGES).forEach((id) => {
    if (!state.status[id]) state.status[id] = 'error';
  });
  state.backendMode = true;
  rebuildFromBooks();
  const last = $('lastScan');
  if (last) last.textContent = new Date(data.ts || Date.now()).toLocaleTimeString();
  renderStatus();
  renderPairs();
  renderList();
}

function clearWsTimers() {
  if (state.wsPingTimer) {
    clearInterval(state.wsPingTimer);
    state.wsPingTimer = null;
  }
  if (state.wsReconnectTimer) {
    clearTimeout(state.wsReconnectTimer);
    state.wsReconnectTimer = null;
  }
}

function scheduleWsReconnect() {
  if (!state.liveMode) return;
  clearWsTimers();
  state.wsReconnectAttempt = (state.wsReconnectAttempt || 0) + 1;
  // Exponential backoff: 1s, 2s, 4s … max 20s — better on flaky mobile networks
  const delay = Math.min(20000, 1000 * Math.pow(2, Math.min(state.wsReconnectAttempt - 1, 4)));
  setWsStatus('WS retry in ' + Math.round(delay / 1000) + 's…', 'warn');
  state.wsReconnectTimer = setTimeout(connectWebSocket, delay);
}

function startWsHeartbeat(ws) {
  if (state.wsPingTimer) clearInterval(state.wsPingTimer);
  // Keep-alive helps mobile carriers / battery savers from dropping idle sockets
  state.wsPingTimer = setInterval(() => {
    if (!state.ws || state.ws.readyState !== 1) return;
    try {
      state.ws.send(JSON.stringify({ type: 'ping', ts: Date.now() }));
    } catch (_) {}
  }, 20000);
}

function disconnectWebSocket() {
  clearWsTimers();
  state.wsConnected = false;
  if (state.ws) {
    try {
      state.ws.onclose = null;
      state.ws.onerror = null;
      state.ws.close();
    } catch (_) {}
    state.ws = null;
  }
}

function connectWebSocket() {
  if (!state.liveMode) return;
  if (typeof WebSocket === 'undefined') {
    setWsStatus('WebSocket not supported', 'bad');
    return;
  }
  // Avoid duplicate sockets
  if (state.ws && (state.ws.readyState === 0 || state.ws.readyState === 1)) return;

  try {
    disconnectWebSocket();
    const url = wsUrl();
    const ws = new WebSocket(url);
    state.ws = ws;
    setWsStatus('WS connecting…', 'warn');

    ws.onopen = () => {
      state.wsConnected = true;
      state.backendMode = true;
      state.wsReconnectAttempt = 0;
      const first = !state.wsEverConnected;
      state.wsEverConnected = true;
      setWsStatus('Live WS · connected', 'live');
      startWsHeartbeat(ws);
      if (first) toast('Mobile live updates on', 'success');
      // Request fresh snapshot
      try { ws.send(JSON.stringify({ type: 'refresh' })); } catch (_) {}
    };

    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (_) { return; }
      if (msg.type === 'scan') {
        applyScanPayload(msg);
        setWsStatus('Live WS · ' + new Date(msg.ts || Date.now()).toLocaleTimeString(), 'live');
      } else if (msg.type === 'hello') {
        setWsStatus('Live WS · every ' + Math.round((msg.intervalMs || 10000) / 1000) + 's', 'live');
      } else if (msg.type === 'pong') {
        // heartbeat ok
      } else if (msg.type === 'error') {
        toast('Live scan: ' + (msg.error || 'error'), 'error');
      }
    };

    ws.onclose = () => {
      state.wsConnected = false;
      state.ws = null;
      if (state.wsPingTimer) {
        clearInterval(state.wsPingTimer);
        state.wsPingTimer = null;
      }
      if (state.liveMode) scheduleWsReconnect();
      else setWsStatus('Live WS: Off', 'warn');
    };

    ws.onerror = () => {
      // onclose will fire and schedule reconnect
      try { ws.close(); } catch (_) {}
    };
  } catch (e) {
    console.warn('WS connect failed', e);
    scheduleWsReconnect();
  }
}

function setLiveMode(on) {
  state.liveMode = !!on;
  const btn = $('liveWsToggle');
  if (btn) {
    btn.textContent = state.liveMode ? 'Live WS: On' : 'Live WS: Off';
    btn.className = state.liveMode ? 'btn btn-primary' : 'btn btn-outline';
  }
  if (state.liveMode) {
    connectWebSocket();
  } else {
    disconnectWebSocket();
    setWsStatus('Live WS: Off', 'warn');
    toast('Live updates paused');
  }
}

/** Mobile: reconnect when app returns to foreground / network comes back */
function installMobileWsLifecycle() {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && state.liveMode) {
      if (!state.wsConnected) connectWebSocket();
      else if (state.ws && state.ws.readyState === 1) {
        try { state.ws.send(JSON.stringify({ type: 'refresh' })); } catch (_) {}
      }
    }
  });

  window.addEventListener('pageshow', (ev) => {
    if (state.liveMode && !state.wsConnected) connectWebSocket();
  });

  window.addEventListener('online', () => {
    if (state.liveMode) {
      toast('Network back · reconnecting live', 'success');
      connectWebSocket();
    }
  });

  window.addEventListener('offline', () => {
    setWsStatus('Offline', 'bad');
  });

  // iOS standalone PWA resume
  window.addEventListener('focus', () => {
    if (state.liveMode && !state.wsConnected) connectWebSocket();
  });
}

async function checkBackendHealth() {
  try {
    const res = await fetch(apiBase() + '/api/health', { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    state.backendMode = true;
    setWsStatus('Backend · ' + (data.exchanges || 0) + ' exchanges', 'live');
    return true;
  } catch (e) {
    state.backendMode = false;
    setWsStatus('No backend · browser mode', 'warn');
    return false;
  }
}

function init() {
  installMobileWsLifecycle();
  checkBackendHealth().then((ok) => {
    if (ok && state.liveMode) connectWebSocket();
  });
  const liveBtn = $('liveWsToggle');
  if (liveBtn) {
    liveBtn.addEventListener('click', () => setLiveMode(!state.liveMode));
  }
  $('scanBtn').addEventListener('click', () => {
    if (state.wsConnected && state.ws && state.ws.readyState === 1) {
      try {
        state.ws.send(JSON.stringify({ type: 'refresh' }));
        toast('Live refresh requested', 'success');
      } catch (_) {
        runScan();
      }
    } else {
      runScan();
    }
  });

  $('autoBtn').addEventListener('click', () => {
    if (state.autoTimer) {
      clearInterval(state.autoTimer);
      state.autoTimer = null;
      $('autoBtn').textContent = 'Auto-scan: Off';
      toast('Auto-scan stopped');
    } else {
      runScan();
      state.autoTimer = setInterval(runScan, 20000);
      $('autoBtn').textContent = 'Auto-scan: On';
      toast('Auto-scan every 20s', 'success');
    }
  });

  document.querySelectorAll('#typeFilters .chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('#typeFilters .chip').forEach((c) => c.classList.remove('active'));
      chip.classList.add('active');
      state.filter = chip.getAttribute('data-type');
      renderList();
    });
  });

  const profitToggle = $('profitableOnly');
  if (profitToggle) {
    profitToggle.addEventListener('change', () => {
      state.profitableOnly = profitToggle.checked;
      renderList();
    });
  }

  $('closeModal').addEventListener('click', () => {
    $('modal').classList.add('hidden');
    if (state.trackTimer) {
      clearInterval(state.trackTimer);
      state.trackTimer = null;
      $('trackBtn').textContent = 'Track 12s';
    }
  });
  $('modal').addEventListener('click', (e) => {
    if (e.target.id === 'modal') $('closeModal').click();
  });

  $('liveCheckBtn').addEventListener('click', async () => {
    $('liveCheckBtn').disabled = true;
    $('liveCheckBtn').textContent = 'Refreshing…';
    try {
      const o = await recheckSelected();
      toast('Live: ' + (o.trackStatus || ''), o.trackStatus === 'still_exists' ? 'success' : '');
    } finally {
      $('liveCheckBtn').disabled = false;
      $('liveCheckBtn').textContent = 'Refresh live books';
    }
  });

  $('trackBtn').addEventListener('click', () => {
    if (state.trackTimer) {
      clearInterval(state.trackTimer);
      state.trackTimer = null;
      $('trackBtn').textContent = 'Track 12s';
      toast('Tracking stopped');
      return;
    }
    $('trackBtn').textContent = 'Tracking… (stop)';
    recheckSelected();
    state.trackTimer = setInterval(async () => {
      const o = await recheckSelected();
      if (o.trackStatus === 'gone') {
        clearInterval(state.trackTimer);
        state.trackTimer = null;
        $('trackBtn').textContent = 'Track 12s';
        toast('Spread gone', 'error');
      }
    }, 12000);
  });

  // Auto-run first scan so the page is not empty
  setTimeout(runScan, 400);
}

document.addEventListener('DOMContentLoaded', init);

#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8787}"
echo "Starting Dennis Mutinda Arbitrage Test Scanner..."
echo "  Web app + backend API on port $PORT"
echo "  Open http://localhost:$PORT"
export PORT
exec node server/server.js

/**
 * Dennis Mutinda CEX Arbitrage Scanner — Backend
 * Fetches public tickers server-side (no browser CORS) for all listed exchanges.
 *
 * Run:  cd server && npm start
 * App:  http://localhost:8787
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8787;
const STATIC_ROOT = path.join(__dirname, '..');
const FETCH_MS = 8000;
const WS_SCAN_MS = Number(process.env.WS_SCAN_MS || 10000); // real-time refresh interval

/** Latest scan cache for REST + WebSocket clients */
let latestScan = {
  ok: true,
  ts: 0,
  durationMs: 0,
  exchanges: [],
  status: {},
  books: {},
};
let scanInFlight = false;
const wsClients = new Set();

const EXCHANGES = {
  binance: {
    name: 'Binance',
    spot: 'https://data-api.binance.vision/api/v3/ticker/bookTicker',
    fut: 'https://fapi.binance.com/fapi/v1/ticker/bookTicker',
  },
  bybit: {
    name: 'Bybit',
    spot: 'https://api.bybit.com/v5/market/tickers?category=spot',
    fut: 'https://api.bybit.com/v5/market/tickers?category=linear',
  },
  bitget: {
    name: 'Bitget',
    spot: 'https://api.bitget.com/api/v2/spot/market/tickers',
    fut: 'https://api.bitget.com/api/v2/mix/market/tickers?productType=USDT-FUTURES',
  },
  okx: {
    name: 'OKX',
    spot: 'https://www.okx.com/api/v5/market/tickers?instType=SPOT',
    fut: 'https://www.okx.com/api/v5/market/tickers?instType=SWAP',
  },
  bingx: {
    name: 'BingX',
    spot: 'https://open-api.bingx.com/openApi/spot/v1/ticker/24hr',
    fut: 'https://open-api.bingx.com/openApi/swap/v2/quote/ticker',
  },
  xt: {
    name: 'XT.com',
    spot: 'https://sapi.xt.com/v4/public/ticker/book',
    fut: 'https://fapi.xt.com/future/market/v1/public/q/ticker/book',
  },
  mexc: {
    name: 'MEXC',
    spot: 'https://api.mexc.com/api/v3/ticker/bookTicker',
  },
  gate: {
    name: 'Gate.io',
    spot: 'https://api.gateio.ws/api/v4/spot/tickers',
    fut: 'https://api.gateio.ws/api/v4/futures/usdt/tickers',
  },
  htmt: {
    name: 'HTX',
    spot: 'https://api.huobi.pro/market/tickers',
  },
  weex: {
    name: 'WEEX',
    spot: 'https://api-spot.weex.com/api/v2/market/tickers',
  },
  bitrue: {
    name: 'Bitrue',
    spot: 'https://openapi.bitrue.com/api/v1/ticker/bookTicker',
  },
  coinex: {
    name: 'CoinEx',
    spot: 'https://api.coinex.com/v1/market/ticker/all',
  },
  kraken: {
    name: 'Kraken',
    spot: 'https://api.kraken.com/0/public/Ticker?pair=XBTUSDT,ETHUSDT,SOLUSDT,XRPUSDT,ADAUSDT,DOTUSDT,LINKUSDT,LTCUSDT,AVAXUSDT,ATOMUSDT',
  },
  lbank: {
    name: 'LBank',
    spot: 'https://api.lbkex.com/v2/supplement/ticker/price.do',
  },
  kucoin: {
    name: 'KuCoin',
    spot: 'https://api.kucoin.com/api/v1/market/allTickers',
    fut: 'https://api-futures.kucoin.com/api/v1/allTickers',
  },
  cryptocom: {
    name: 'Crypto.com',
    spot: 'https://api.crypto.com/exchange/v1/public/get-tickers',
  },
  bitfinex: {
    name: 'Bitfinex',
    spot: 'https://api-pub.bitfinex.com/v2/tickers?symbols=ALL',
  },
  // These often need keys or have unstable public endpoints — still attempted
  blofin: {
    name: 'Blofin',
    spot: 'https://openapi.blofin.com/api/v1/market/tickers',
  },
  levex: {
    name: 'Levex',
    spot: 'https://api.levex.com/api/v1/ticker/24hr',
  },
};

const QUOTE_SUFFIXES = ['USDT', 'USDC'];

function normSym(s) {
  s = String(s || '').toUpperCase().replace(/[-_/]/g, '');
  if (s.endsWith('USD') && !s.endsWith('USDT') && !s.endsWith('USDC')) s += 'T';
  // Bitfinex style tBTCUST -> BTCUSDT-ish
  if (s.startsWith('T') && s.length > 4) {
    const rest = s.slice(1);
    if (rest.endsWith('UST')) s = rest.replace(/UST$/, 'USDT');
  }
  return s;
}

function isQuotePair(s) {
  return QUOTE_SUFFIXES.some((q) => s.endsWith(q));
}

function isLeverageToken(s) {
  return /UPUSDT$|DOWNUSDT$|BULLUSDT$|BEARUSDT$|3L|3S|5L|5S/.test(s);
}

function fetchJson(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(url);
    } catch (e) {
      return reject(e);
    }
    const lib = parsed.protocol === 'http:' ? http : https;
    const req = lib.request(
      {
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'User-Agent': 'DM-CEX-Arb-Scanner/1.0',
        },
        timeout: timeoutMs || FETCH_MS,
      },
      (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (c) => {
          body += c;
          if (body.length > 25e6) {
            req.destroy();
            reject(new Error('response too large'));
          }
        });
        res.on('end', () => {
          if (res.statusCode && res.statusCode >= 400) {
            return reject(new Error('HTTP ' + res.statusCode));
          }
          try {
            resolve(JSON.parse(body));
          } catch (e) {
            reject(new Error('invalid JSON'));
          }
        });
      }
    );
    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('timeout'));
    });
    req.end();
  });
}

function parseBooks(exchangeId, data, market) {
  const out = {};
  const put = (sym, bid, ask, bidQty, askQty, vol) => {
    let s = normSym(sym);
    if (!s || !isQuotePair(s) || isLeverageToken(s)) return;
    const b = parseFloat(bid);
    const a = parseFloat(ask);
    if (!(b > 0) || !(a > 0) || a < b) return;
    const bq = parseFloat(bidQty) || 0;
    const aq = parseFloat(askQty) || 0;
    let liq = Math.min(b * bq, a * aq);
    const volume = parseFloat(vol) || 0;
    if (!(liq > 0)) liq = volume > 0 ? Math.min(volume, 100000) : 5000;
    out[s] = {
      exchange: exchangeId,
      market,
      symbol: s,
      bid: b,
      ask: a,
      bidQty: bq,
      askQty: aq,
      liquidityUsdt: liq,
      volume24hUsdt: volume,
    };
  };

  try {
    if (exchangeId === 'binance' || exchangeId === 'mexc' || exchangeId === 'bitrue') {
      (Array.isArray(data) ? data : [data]).forEach((t) =>
        put(t.symbol, t.bidPrice, t.askPrice, t.bidQty, t.askQty)
      );
    } else if (exchangeId === 'bybit') {
      ((data.result && data.result.list) || []).forEach((t) =>
        put(t.symbol, t.bid1Price, t.ask1Price, t.bid1Size, t.ask1Size, t.turnover24h)
      );
    } else if (exchangeId === 'okx') {
      (data.data || []).forEach((t) =>
        put(String(t.instId).replace(/-/g, ''), t.bidPx, t.askPx, t.bidSz, t.askSz, t.volCcy24h)
      );
    } else if (exchangeId === 'bitget') {
      const arr = data.data || data;
      (Array.isArray(arr) ? arr : []).forEach((t) => {
        const sym = String(t.symbol || '').replace(/_/g, '');
        put(sym, t.bidPr || t.bestBid || t.bidPrice, t.askPr || t.bestAsk || t.askPrice, t.bidSz, t.askSz, t.usdtVolume || t.quoteVolume);
      });
    } else if (exchangeId === 'gate') {
      (Array.isArray(data) ? data : []).forEach((t) => {
        const sym = String(t.currency_pair || t.contract || '').replace(/_/g, '');
        put(sym, t.highest_bid, t.lowest_ask, t.highest_size, t.lowest_size, t.quote_volume);
      });
    } else if (exchangeId === 'kucoin') {
      const list = (data.data && data.data.ticker) || data.data || [];
      (Array.isArray(list) ? list : []).forEach((t) =>
        put(String(t.symbol || '').replace(/-/g, ''), t.buy || t.bestBidPrice, t.sell || t.bestAskPrice, 0, 0, t.volValue)
      );
    } else if (exchangeId === 'htmt') {
      (data.data || []).forEach((t) => put(t.symbol, t.bid, t.ask, t.bidSize, t.askSize, t.vol));
    } else if (exchangeId === 'coinex') {
      const tickers = (data.data && data.data.ticker) || {};
      Object.keys(tickers).forEach((sym) => {
        const t = tickers[sym];
        put(sym, t.buy, t.sell, 0, 0, t.vol);
      });
    } else if (exchangeId === 'kraken') {
      const result = data.result || {};
      Object.keys(result).forEach((pair) => {
        const t = result[pair];
        let sym = pair;
        if (/XBT.*USDT|USDT.*XBT/.test(pair)) sym = 'BTCUSDT';
        else if (/ETH.*USDT/.test(pair)) sym = 'ETHUSDT';
        else if (/SOL.*USDT/.test(pair)) sym = 'SOLUSDT';
        else if (/XRP.*USDT/.test(pair)) sym = 'XRPUSDT';
        else if (/ADA.*USDT/.test(pair)) sym = 'ADAUSDT';
        else if (/DOT.*USDT/.test(pair)) sym = 'DOTUSDT';
        else if (/LINK.*USDT/.test(pair)) sym = 'LINKUSDT';
        else if (/LTC.*USDT/.test(pair)) sym = 'LTCUSDT';
        else if (/AVAX.*USDT/.test(pair)) sym = 'AVAXUSDT';
        else if (/ATOM.*USDT/.test(pair)) sym = 'ATOMUSDT';
        put(sym, t.b && t.b[0], t.a && t.a[0], t.b && t.b[1], t.a && t.a[1]);
      });
    } else if (exchangeId === 'bingx') {
      const arr = data.data || data;
      (Array.isArray(arr) ? arr : []).forEach((t) =>
        put(t.symbol, t.bidPrice || t.bid, t.askPrice || t.ask, t.bidQty, t.askQty, t.quoteVolume)
      );
    } else if (exchangeId === 'cryptocom') {
      ((data.result && data.result.data) || []).forEach((t) =>
        put(String(t.i || '').replace(/-/g, ''), t.b, t.k, t.bs, t.ks, t.vv)
      );
    } else if (exchangeId === 'bitfinex') {
      // [[SYMBOL, BID, BID_SIZE, ASK, ASK_SIZE, ...], ...]
      if (Array.isArray(data)) {
        data.forEach((row) => {
          if (!Array.isArray(row) || row.length < 5) return;
          const raw = String(row[0] || '');
          if (!raw.startsWith('t')) return;
          let sym = raw.slice(1);
          if (sym.endsWith('UST')) sym = sym.slice(0, -3) + 'USDT';
          put(sym, row[1], row[3], row[2], row[4]);
        });
      }
    } else if (exchangeId === 'xt') {
      const arr = (data.result && data.result) || data.data || data;
      (Array.isArray(arr) ? arr : []).forEach((t) => {
        const sym = String(t.s || t.symbol || '').replace(/_/g, '');
        put(sym, t.bp || t.bid || t.bidPrice, t.ap || t.ask || t.askPrice, t.bq, t.aq);
      });
    } else if (exchangeId === 'lbank') {
      const arr = data.data || data;
      if (Array.isArray(arr)) {
        arr.forEach((t) => {
          const sym = String(t.symbol || '').replace(/_/g, '');
          const px = t.price || t.ticker || t;
          // LBank price endpoint may only have last price — skip if no book
          if (t.bid && t.ask) put(sym, t.bid, t.ask, 0, 0);
        });
      }
    } else if (exchangeId === 'weex' || exchangeId === 'blofin' || exchangeId === 'levex') {
      const arr = data.data || data.result || data;
      if (Array.isArray(arr)) {
        arr.forEach((t) => {
          put(
            t.symbol || t.instId || t.pair,
            t.bidPrice || t.bid || t.buy || t.bestBid,
            t.askPrice || t.ask || t.sell || t.bestAsk,
            t.bidQty || t.bidSize,
            t.askQty || t.askSize,
            t.quoteVolume || t.volCcy24h
          );
        });
      } else if (arr && typeof arr === 'object') {
        Object.keys(arr).forEach((sym) => {
          const t = arr[sym];
          if (t && typeof t === 'object') {
            put(sym, t.bid || t.buy, t.ask || t.sell, 0, 0, t.vol);
          }
        });
      }
    } else {
      const arr = data.data || data.result || data;
      if (Array.isArray(arr)) {
        arr.forEach((t) =>
          put(t.symbol || t.instId || t.pair, t.bidPrice || t.bid || t.buy, t.askPrice || t.ask || t.sell, t.bidQty, t.askQty)
        );
      }
    }
  } catch (err) {
    console.warn('parse', exchangeId, err.message);
  }
  return out;
}

async function loadExchange(id, cfg) {
  const books = {};
  let status = 'ok';
  const errors = [];

  async function load(url, market) {
    const data = await fetchJson(url);
    const parsed = parseBooks(id, data, market);
    Object.keys(parsed).forEach((k) => {
      books[market === 'futures' ? k + '__FUT' : k] = parsed[k];
    });
  }

  const jobs = [];
  if (cfg.spot) {
    jobs.push(
      load(cfg.spot, 'spot').catch((e) => {
        errors.push('spot:' + e.message);
      })
    );
  }
  if (cfg.fut) {
    jobs.push(
      load(cfg.fut, 'futures').catch((e) => {
        errors.push('fut:' + e.message);
      })
    );
  }
  await Promise.all(jobs);

  if (!Object.keys(books).length) {
    status = errors.length ? 'error' : 'empty';
  }
  return { books, status, errors, pairCount: Object.keys(books).length };
}

async function scanAll() {
  const ids = Object.keys(EXCHANGES);
  const books = {};
  const status = {};
  const meta = {};

  await Promise.all(
    ids.map(async (id) => {
      try {
        const res = await loadExchange(id, EXCHANGES[id]);
        books[id] = res.books;
        status[id] = res.status;
        meta[id] = { pairCount: res.pairCount, errors: res.errors, name: EXCHANGES[id].name };
      } catch (e) {
        books[id] = {};
        status[id] = 'error';
        meta[id] = { pairCount: 0, errors: [e.message], name: EXCHANGES[id].name };
      }
    })
  );

  return {
    ok: true,
    ts: Date.now(),
    exchanges: Object.keys(EXCHANGES).map((id) => ({
      id,
      name: EXCHANGES[id].name,
      status: status[id],
      pairCount: (meta[id] && meta[id].pairCount) || 0,
    })),
    status,
    books,
  };
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const map = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.webmanifest': 'application/manifest+json',
  };
  return map[ext] || 'application/octet-stream';
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function serveStatic(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath.split('?')[0]);
  if (rel === '/') rel = '/index.html';
  const filePath = path.normalize(path.join(STATIC_ROOT, rel));
  if (!filePath.startsWith(STATIC_ROOT)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Not found');
    }
    res.writeHead(200, { 'Content-Type': contentType(filePath) });
    res.end(data);
  });
}

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const ws of wsClients) {
    if (ws.readyState === 1) {
      try { ws.send(msg); } catch (_) {}
    }
  }
}

async function runCachedScan() {
  if (scanInFlight) return latestScan;
  scanInFlight = true;
  try {
    const t0 = Date.now();
    const result = await scanAll();
    result.durationMs = Date.now() - t0;
    latestScan = result;
    broadcast({ type: 'scan', ...result });
    return result;
  } catch (e) {
    const err = { type: 'error', error: e.message, ts: Date.now() };
    broadcast(err);
    throw e;
  } finally {
    scanInFlight = false;
  }
}

const server = http.createServer(async (req, res) => {
  const urlPath = req.url || '/';

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  if (urlPath.startsWith('/api/health')) {
    return sendJson(res, 200, {
      ok: true,
      exchanges: Object.keys(EXCHANGES).length,
      list: Object.keys(EXCHANGES),
      ws: true,
      lastScanTs: latestScan.ts || null,
      clients: wsClients.size,
    });
  }

  if (urlPath.startsWith('/api/exchanges')) {
    return sendJson(res, 200, {
      exchanges: Object.keys(EXCHANGES).map((id) => ({
        id,
        name: EXCHANGES[id].name,
        hasSpot: !!EXCHANGES[id].spot,
        hasFutures: !!EXCHANGES[id].fut,
      })),
    });
  }

  if (urlPath.startsWith('/api/scan')) {
    try {
      // Return cache if fresh (< 8s), else rescan
      if (latestScan.ts && Date.now() - latestScan.ts < 8000 && Object.keys(latestScan.books || {}).length) {
        return sendJson(res, 200, latestScan);
      }
      const result = await runCachedScan();
      return sendJson(res, 200, result);
    } catch (e) {
      return sendJson(res, 500, { ok: false, error: e.message });
    }
  }

  serveStatic(req, res, urlPath);
});

const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (ws) => {
  wsClients.add(ws);
  console.log('WS client connected · total', wsClients.size);

  // Snapshot immediately
  try {
    ws.send(JSON.stringify({ type: 'hello', ws: true, intervalMs: WS_SCAN_MS, ts: Date.now() }));
    if (latestScan.ts) {
      ws.send(JSON.stringify({ type: 'scan', ...latestScan }));
    }
  } catch (_) {}

  ws.on('message', async (raw) => {
    let msg = {};
    try { msg = JSON.parse(String(raw)); } catch (_) { return; }
    if (msg.type === 'ping') {
      try { ws.send(JSON.stringify({ type: 'pong', ts: Date.now() })); } catch (_) {}
    }
    if (msg.type === 'scan' || msg.type === 'refresh') {
      try {
        await runCachedScan();
      } catch (e) {
        try { ws.send(JSON.stringify({ type: 'error', error: e.message })); } catch (_) {}
      }
    }
  });

  ws.on('close', () => {
    wsClients.delete(ws);
    console.log('WS client left · total', wsClients.size);
  });
  ws.on('error', () => {
    wsClients.delete(ws);
  });
});

// Background real-time scanner
setInterval(() => {
  if (wsClients.size === 0 && latestScan.ts && Date.now() - latestScan.ts < WS_SCAN_MS) return;
  runCachedScan().catch((e) => console.warn('bg scan', e.message));
}, WS_SCAN_MS);

// Initial warm-up scan
runCachedScan().catch((e) => console.warn('warmup scan', e.message));

server.listen(PORT, '0.0.0.0', () => {
  console.log('DM CEX Arb web app on http://0.0.0.0:' + PORT);
  console.log('WebSocket: ws://0.0.0.0:' + PORT + '/ws  · interval', WS_SCAN_MS + 'ms');
  console.log('Exchanges:', Object.keys(EXCHANGES).join(', '));
});
